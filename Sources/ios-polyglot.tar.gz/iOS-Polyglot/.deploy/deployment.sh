POLYGLOT_DIR=$(pwd)
POLYGLOT_DIR_NAME=${PWD##*/}
DEST="Homebrew-formulae"
SOURCES_DIR="Sources"
FORMULA_DIR="Formula"
TEMP="temp$(date | openssl sha -sha256  | cut -d ' ' -f 2)"

cd ..
mkdir $TEMP && cd $TEMP || exit 1

rm -rf $DEST
git clone git@github.com:infinum/Homebrew-formulae.git
cd $DEST

rm -rf "$SOURCES_DIR/ios-polyglot.tar.gz"
cd ../..
echo "Creating tarball from $POLYGLOT_DIR_NAME in: $TEMP/Homebrew-formulae/$SOURCES_DIR/ios-polyglot.tar.gz"
tar -czf "$TEMP/Homebrew-formulae/$SOURCES_DIR/ios-polyglot.tar.gz" $POLYGLOT_DIR_NAME

cd $TEMP/$DEST/$FORMULA_DIR
SHA256=$(openssl sha -sha256 ../$SOURCES_DIR/ios-polyglot.tar.gz | cut -d ' ' -f 2) || exit 1
filename="polyglot1$SHA256.rb"

echo "Creating $TEMP/$DEST/$FORMULA_DIR/$filename"
touch $filename && rm -rf $filename || exit 2
touch $filename || exit 3

while IFS= read -r line; do
  if echo $line | egrep -q ".*sha256.*"; then
    echo "Replacing old sha256 with: $SHA256"
    echo "    sha256 \"$SHA256\"" >> $filename
  else
    printf '%s\n' "$line" >> $filename
  fi
done < polyglot.rb

mv $filename polyglot.rb || exit 4

git commit -am "Version up"
git push || exit 5

echo "Cleaning up"
cd $POLYGLOT_DIR
rm -rf ../$TEMP
