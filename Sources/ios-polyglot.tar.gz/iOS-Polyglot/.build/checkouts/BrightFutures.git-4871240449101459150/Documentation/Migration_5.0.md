# Migrating from 4.1.1 to 5.0.0

This migration guide is a work in progress. 

For now, see https://github.com/Thomvis/BrightFutures/compare/v4.1.1...v5.0.0