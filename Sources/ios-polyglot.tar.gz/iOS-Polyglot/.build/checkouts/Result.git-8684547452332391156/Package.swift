import PackageDescription

let package = Package(
    name: "Result",
    targets: [
        Target(
            name: "Result"
        )
    ]
)
