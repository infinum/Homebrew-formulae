//
//  SyncSpine.swift
//  polyglot
//
//  Created by Filip Beć on 10/11/16.
//
//

import Foundation
import Spine
import Result
import BrightFutures

class SyncSpine: Spine {

    private static let authenticationHeader: String = "X-Auth-Token"

    static var shared: SyncSpine = {
        let client = HTTPClient()
        client.setHeader("Accept", to: "application/json")
        client.setHeader("Content-Type", to: "application/json")

        let url = URL(string: "https://infinum.polyglothq.com/api/v2")!
        let spine = SyncSpine(baseURL: url, networkClient: client)

        spine.registerResource(Session.self)
        spine.registerResource(Language.self)
        spine.registerResource(Project.self)
        spine.registerResource(Translation.self)
        spine.registerResource(TranslationKey.self)

        return spine
    }()

    func login(with token: String) {
        guard let client = networkClient as? HTTPClient else {
            return
        }
        client.setHeader(SyncSpine.authenticationHeader, to: token)
    }

    func logout() {
        guard let client = self.networkClient as? HTTPClient else {
            return
        }
        client.removeHeader(SyncSpine.authenticationHeader)
    }

    func syncFind<T>(_ query: Query<T>) -> Result<(resources: ResourceCollection, meta: Metadata?, jsonapi: JSONAPIData?), SpineError> {
        return loadSync { () -> Future<(resources: ResourceCollection, meta: Metadata?, jsonapi: JSONAPIData?), SpineError> in
            return super.find(query)
        }
    }

    func syncFind<T: Resource>(_ ids: [String], ofType type: T.Type) -> Result<(resources: ResourceCollection, meta: Metadata?, jsonapi: JSONAPIData?), SpineError> {
        let query = Query(resourceType: type, resourceIDs: ids)
        return syncFind(query)
    }

    func syncFindOne<T>(_ query: Query<T>) -> Result<(resource: T, meta: Metadata?, jsonapi: JSONAPIData?), SpineError> {
        return loadSync { () -> Future<(resource: T, meta: Metadata?, jsonapi: JSONAPIData?), SpineError> in
            return super.findOne(query)
        }
    }

    func syncFindOne<T: Resource>(_ id: String, ofType type: T.Type) -> Result<(resource: T, meta: Metadata?, jsonapi: JSONAPIData?), SpineError> {
        let query = Query(resourceType: type, resourceIDs: [id])
        return syncFindOne(query)
    }

    func syncFindAll<T: Resource>(_ type: T.Type) -> Result<(resources: ResourceCollection, meta: Metadata?, jsonapi: JSONAPIData?), SpineError> {
        let query = Query(resourceType: type)
        return syncFind(query)
    }


    // MARK: Loading

    func syncLoad<T>(_ resource: T, queryCallback: ((Query<T>) -> Query<T>)? = nil) -> Result<T, SpineError> {
        return loadSync { () -> Future<T, SpineError> in
            return super.reload(resource, queryCallback: queryCallback)
        }
    }

    func syncReload<T>(_ resource: T, queryCallback: ((Query<T>) -> Query<T>)? = nil) -> Result<T, SpineError> {
        return loadSync { () -> Future<T, SpineError> in
            return super.reload(resource, queryCallback: queryCallback)
        }
    }


    // MARK: Paginating

    open func syncLoadNextPageOfCollection(_ collection: ResourceCollection) -> Result<ResourceCollection, SpineError> {
        return loadSync { () -> Future<ResourceCollection, SpineError> in
            return super.loadNextPageOfCollection(collection)
        }
    }

    open func syncLoadPreviousPageOfCollection(_ collection: ResourceCollection) -> Result<ResourceCollection, SpineError> {
        return loadSync { () -> Future<ResourceCollection, SpineError> in
            return super.loadPreviousPageOfCollection(collection)
        }
    }


    // MARK: Persisting

    func syncSave<T: Resource>(_ resource: T) -> Result<T, SpineError> {
        return loadSync { () -> Future<T, SpineError> in
            return super.save(resource)
        }
    }

    func syncDelete<T: Resource>(_ resource: T) -> Result<Void, SpineError> {
        return loadSync { () -> Future<Void, SpineError> in
            return super.delete(resource)
        }
    }

    func syncLoadAll<T>(_ query: Query<T>) -> Result<ResourceCollection, SpineError> {
        let response = syncFind(query)
        var result: Result<ResourceCollection, SpineError>

        switch response {
        case .success(let responseData):
            result = Result<ResourceCollection, SpineError>(value: responseData.resources)
        case .failure(let error):
            result = Result<ResourceCollection, SpineError>(error: error)
        }

        while let collection = result.value, collection.nextURL != nil {
            result = syncLoadNextPageOfCollection(collection)
        }
        return result
    }

    func syncLoadAll<T: Resource>(ofType type: T.Type) -> Result<ResourceCollection, SpineError> {
        let query = Query(resourceType: type)
        return syncLoadAll(query)
    }


    // MARK: Sync method wrapper

    private func loadSync<T>(block: () -> Future<T, SpineError>) -> Result<T, SpineError> {
        let semaphore = DispatchSemaphore(value: 0)
        let future = block().onComplete(DispatchQueue.global().context) { _ in
            semaphore.signal()
        }
        semaphore.wait()
        return future.result!
    }
    
}
