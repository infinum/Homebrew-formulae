//
//  TranslationsSerializer.swift
//  polyglot
//
//  Created by Filip Beć on 16/11/16.
//
//

import Foundation

class TranslationsSerializer {

    static func serialized(_ translations: [TranslationKey], for languageId: String) -> String{
        var string: String = ""
        for translationKey in translations {
            guard let key = translationKey.name else {
                continue
            }
            string += "\"" + key + "\" = \""

            if let translation = translationKey.translation(for: languageId), let translationValue = translation.value {
                string += translationValue.cleanTranslation
            } else {
                // use translation key in case when translation doesn't exist
                string += key;
            }
            string += "\";\n"
        }
        return string
    }

}
