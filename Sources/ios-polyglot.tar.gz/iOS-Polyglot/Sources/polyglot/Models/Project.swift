//
//  Project.swift
//  polyglot
//
//  Created by Filip Beć on 10/11/16.
//
//

import Foundation
import Spine

class Project: Resource {
    var name: String?
    var defaultLanguage: Language?
    var token: String?
    var createdAt: Date?
    var updatedAt: Date?

    override class var resourceType: ResourceType {
        return "projects"
    }

    override class var fields: [Field] {
        return fieldsFromDictionary(
            [
                "name": Attribute(),
                "defaultLanguage": ToOneRelationship(Language.self),
                "token": Attribute(),
                "createdAt": DateAttribute().serializeAs("created_at"),
                "updatedAt": DateAttribute().serializeAs("updated_at")
            ]
        )
    }

    convenience init(id: String) {
        self.init()
        self.id = id
    }

    var formattedListOutput: String? {
        guard let _id = id, let _name = name else {
            return nil
        }
        return "[\(_id)]\t - \(_name)"
    }
}
