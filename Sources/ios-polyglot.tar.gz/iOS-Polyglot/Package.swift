import PackageDescription

let package = Package(
    name: "polyglot",
    dependencies: [
        .Package(
            url: "https://github.com/jakeheis/SwiftCLI.git",
            majorVersion: 2,
            minor: 0
        ),
        .Package(
            url: "https://github.com/Truba/Spine.git",
            majorVersion: 1
        ),
        .Package(
            url: "https://github.com/antitypical/Result.git",
            majorVersion: 3
        ),
        .Package(
            url: "https://github.com/behrang/YamlSwift.git",
            majorVersion: 3
        )
    ]
)
