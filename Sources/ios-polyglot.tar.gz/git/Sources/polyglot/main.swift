import Foundation
import SwiftCLI

let loginCommand = LoginCommand()
let setupCommand = SetupCommand()
let pullCommand = PullCommand()
let projectCommand = ProjectCommand()

CLI.setup(name: "polyglot", version: "1.0")
CLI.register(commands:
    [
        loginCommand,
        setupCommand,
        pullCommand,
        projectCommand,
    ]
)

let _ = CLI.go()

// MARK: Exit helpers
enum Exit {
    case success
    case failure
}

func exit(with type: Exit, message: String? = nil) {
    switch type {
    case .success:
        // TODO print message
        exit(EXIT_SUCCESS)
    case .failure:
        Output.write(message, to: .error)
        exit(EXIT_FAILURE)
    }
}
