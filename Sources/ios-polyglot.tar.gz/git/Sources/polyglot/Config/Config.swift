//
//  Config.swift
//  polyglot
//
//  Created by Filip Beć on 14/11/16.
//
//

import Foundation
import Yaml

enum ProgrammingLanguage: String {
    case swift = "swift"
    case objc = "objc"
}

class Config {

    let language: ProgrammingLanguage
    let projects: [ConfigProject]

    init?(yaml: Yaml) {
        guard let language = ProgrammingLanguage(rawValue: yaml["language"].string ?? "") else {
            return nil
        }

        guard let projectsYaml = yaml["projects"].array else {
            return nil
        }

        var projects: [ConfigProject] = []
        for projectYaml in projectsYaml {
            guard let project = ConfigProject(yaml: projectYaml) else {
                return nil
            }
            projects.append(project)
        }
        self.language = language
        self.projects = projects
    }

}

class ConfigProject {

    let id: String
    let path: String
    let sourceFilesPath: String?
    let useOldNaming: Bool

    init?(yaml: Yaml) {
        guard let id = yaml["id"].string else {
            return nil
        }

        guard let path = yaml["path"].string else {
            return nil
        }

        self.id = id
        self.path = path
        self.sourceFilesPath = yaml["sourceFilesPath"].string
        self.useOldNaming = yaml["useOldNaming"].bool ?? false
    }
}
