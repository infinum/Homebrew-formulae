//
//  ConfigManager.swift
//  polyglot
//
//  Created by Filip Beć on 14/11/16.
//
//

import Foundation
import Yaml

class ConfigManager {

    static var shared: ConfigManager = ConfigManager()
    private init() {}

    var defaultTranslationsPath = "./Resources/Translations/"
    var defaultSourceFilesPath = "./Common/Translations/"
    var configFilename = "polyglot.yml"
    var configExist: Bool {
        return _fileManager.fileExists(atPath: _configPath)
    }

    private var _fileManager = FileManager.default
    private var _configPath: String {
        return "./" + configFilename
    }

    func saveConfig(with project: Project, language: ProgrammingLanguage, translationsPath: String, sourceFilesPath: String? = nil) {
        guard let projectId = project.id, let name = project.name else {
            exit(with: .failure, message: "Invalid project id or name")
            return
        }

        var config =
            [
                "language: \(language.rawValue)\n",
                "projects:\n",
                "  -\n",
                "    id: \(projectId)\t# Project: \(name)\n",
                "    path: \(translationsPath)\n"
            ]

        // swift source files
        
        guard let _sourceFilesPath = sourceFilesPath else {
            exit(with: .failure, message: "Invalid path for source files")
            return
        }
        config.append("    sourceFilesPath: \(_sourceFilesPath)\n")
        

        let configString = config.reduce("", +)

        _fileManager.createFile(
            atPath: _configPath,
            contents: configString.data(using: .utf8),
            attributes: nil
        )
    }

    func loadConfig() -> Config {
        let string: String
        do {
            string = try String(contentsOfFile: _configPath, encoding: .utf8)
        } catch let error {
            Output.write(error.localizedDescription, to: .error)
            exit(EXIT_FAILURE)
        }

        let yaml: Yaml
        do {
            yaml = try Yaml.load(string)
        } catch let error {
            Output.write(error.localizedDescription, to: .error)
            exit(EXIT_FAILURE)
        }

        guard let config = Config(yaml: yaml) else {
            Output.write("Invalid configuration file syntax", to: .error)
            exit(EXIT_FAILURE)
        }

        return config
    }

}
