//
//  Ident.swift
//  polyglot
//
//  Created by Filip Beć on 18/01/2017.
//
//

import Foundation

// MARK: - Ident -
typealias IdentLevel = Int

extension String {

    init(identLevel: IdentLevel) {
        let ident = (0..<identLevel).reduce("", { (result, _) -> String in
            return result + "    "
        })
        self.init(format: ident)
    }
}

// MARK: - Clean names -
extension String {

    var cleanVaribleName: String {
        return self
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .enumerated()
            .map({ ($0 == 0 ? $1.lowercased() : $1.capitalized) })
            .joined(separator: "")
            .underscoreEscapedFirstNotLetterCharacter
            .escapeKeywords
    }

    var cleanEnumName: String {
        return self
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .map { $0.capitalized }
            .joined()
            .underscoreEscapedFirstNotLetterCharacter
    }

    var cleanCaseName: String {
        return self.cleanVaribleName
    }

    var cleanTranslation: String {
        return self
            .replacingOccurrences(of: "\"", with: "\\\"")
            .replacingOccurrences(of: "%s", with: "%@")
    }

    private var underscoreEscapedFirstNotLetterCharacter: String {
        if let firstChar = self.unicodeScalars.first {
            if !CharacterSet.letters.contains(firstChar)  {
                return "_" + self
            }
        }
        return self
    }

    private var escapeKeywords: String {
        let keywords = ["associatedtype", "class", "deinit", "enum", "extension", "fileprivate", "func", "import", "init", "inout", "internal", "let", "operator", "private", "protocol", "public", "static", "struct", "subscript", "typealias", "var", "break", "case", "continue", "default", "defer", "do", "else", "fallthrough", "for", "guard", "if", "in", "repeat", "return", "switch", "where", "while", "as", "Any", "catch", "false", "is", "nil", "rethrows", "super", "self", "Self", "throw", "throws", "true", "try", "_"]

        // WARNING: Maybe this also
        // associativity, convenience, dynamic, didSet, final, get, infix, indirect, lazy, left, mutating, none, nonmutating, optional, override, postfix, precedence, prefix, Protocol, required, right, set, Type, unowned, weak, willSet
        if keywords.contains(self) {
            return "`\(self)`"
        }
        return self
    }
}
