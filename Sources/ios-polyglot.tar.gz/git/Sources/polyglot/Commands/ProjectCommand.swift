//
//  ProjectCommand.swift
//  polyglot
//
//  Created by Filip Beć on 11/11/16.
//
//

import Foundation
import SwiftCLI
import Spine

class ProjectCommand: Command {

    let name: String = "projects"
    let shortDescription: String = "Prints all projects"
    let signature: String = ""

    private let _keychain: Keychain = Keychain.shared
    private let _spine: SyncSpine = SyncSpine.shared
    private var _allProjects: Bool = false

    func execute(arguments: CommandArguments) throws {
        printAllProjects()
    }

    func printAllProjects() {
        if _keychain.token == nil {
            let login = LoginCommand()
            login.executeLogin()
        }

        let projects = loadAllProjects()
        projects.forEach {
            Output.write($0.formattedListOutput)
        }
    }

    func loadAllProjects() -> [Project] {
        let result = _spine.syncLoadAll(ofType: Project.self)

        switch result {
        case .success(let response):
            return response.flatMap { $0 as? Project }

        case .failure(let error):
            ErrorHandler.processError(error)
        }
        return []
    }

}
