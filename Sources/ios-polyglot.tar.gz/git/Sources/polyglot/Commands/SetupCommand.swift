//
//  SetupCommand.swift
//  polyglot
//
//  Created by Filip Beć on 09/11/16.
//
//

import Foundation
import SwiftCLI
import Spine
import Yaml

class SetupCommand: OptionCommand {

    let name: String = "setup"
    let shortDescription: String = "Setup new polyglot project"
    let signature: String = "[<project-id>]"

    private let _spine: SyncSpine = SyncSpine.shared
    private let _configManager = ConfigManager.shared
    private let _keychain = Keychain.shared
    private var _printProjects = false

    func setupOptions(options: OptionRegistry) {
        options.add(flags: ["-l", "--list"], usage: "List all polyglot projects") {
            self._printProjects = true
        }
    }

    func execute(arguments: CommandArguments) throws {
        _performCheckForExistingConfigFile()

        // Check if user is logged in
        if _keychain.token == nil {
            let login = LoginCommand()
            login.executeLogin()
        }

        // execute option -l
        if _printProjects {
            _printAllProjects()
        }

        // enter required information
        let projectId = arguments.optionalArgument("project-id") ?? _enterProjectId()
        guard let project = _loadProjectWithID(projectId) else {
            exit(with: .failure, message: "Project with ID \(projectId) not found")
            return
        }

        let programmingLanguage = _enterProgrammingLanguage()
        let path = _enterTranslationsPath()

        let sourceFilesPath = _enterSwiftFilesPath()
        
        // save config
        _configManager.saveConfig(
            with: project,
            language: programmingLanguage,
            translationsPath: path,
            sourceFilesPath: sourceFilesPath
        )
        Output.write("Successfully created config file polyglot.yml", to: .success)

        // reset command state
        _printProjects = false
    }

    // MARK: Private

    private func _performCheckForExistingConfigFile() {
        if _configManager.configExist {
            let message = "\(_configManager.configFilename) already exist. Do you want to override it?"
            let input = Input.awaitYesNoInput(message: message)
            if !input {
                exit(with: .success)
            }
        }
    }

    private func _printAllProjects() {
        let command = ProjectCommand()
        command.printAllProjects()
        Output.write("\n")
    }

    private func _enterProjectId() -> String {
        return Input.awaitInputWithValidation(message: "Project ID:", validation: { (projectId) -> Bool in
            return !projectId.isEmpty
        })
    }

    private func _enterProgrammingLanguage() -> ProgrammingLanguage {
        let message = "Programming language (default is swift) [swift/objc]:"
        return Input.awaitInputWithConversion(message: message) { (input) -> ProgrammingLanguage? in
            if input.isEmpty {
                return ProgrammingLanguage.swift
            }
            return ProgrammingLanguage(rawValue: input)
        }
    }

    private func _enterTranslationsPath() -> String {
        let defaultPath = _configManager.defaultTranslationsPath
        let message = "Path for translations (default is \(defaultPath)):"
        return Input.awaitInputWithConversion(message: message, conversion: { (input) -> String? in
            if input.isEmpty {
                return defaultPath
            }
            return input
        })
    }

    private func _enterSwiftFilesPath() -> String {
        let defaultPath = _configManager.defaultSourceFilesPath
        let message = "Path for source files (default is \(defaultPath)):"
        return Input.awaitInputWithConversion(message: message, conversion: { (input) -> String? in
            if input.isEmpty {
                return defaultPath
            }
            return input
        })
    }

    private func _loadProjectWithID(_ id: String) -> Project? {
        let result = _spine.syncFindOne(id, ofType: Project.self)

        switch result {
        case .success(let response):
            return response.resource
        case .failure(let error):
            ErrorHandler.processError(error)
        }
        return nil
    }

}
