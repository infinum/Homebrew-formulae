//
//  LoginCommand.swift
//  polyglot
//
//  Created by Filip Beć on 09/11/16.
//
//

import Foundation
import SwiftCLI
import Spine
import Result
import BrightFutures

/**
    Login to the polyglot server and obtain auth token used for other API requests.
*/

class LoginCommand: OptionCommand {

    let name: String = "login"
    let shortDescription: String = "Login to the polyglot server"
    let signature: String = ""

    private let _spine = SyncSpine.shared
    private let _keychain = Keychain.shared
    
    private var _email: String = ""
    private var _password: String = ""

    func setupOptions(options: OptionRegistry) {
        options.add(keys: ["-e", "--email"], usage: "Infinum single sign in email", valueSignature: "email") { (value) in
            self._email = value
        }
    }

    func execute(arguments: CommandArguments) throws {
        executeLogin()

        self._email = ""
        self._password = ""
    }

    func executeLogin() {
        if _email.isEmpty {
            _enterEmail()
        }
        if _password.isEmpty {
            _enterPassword()
        }

        let session = Session(email: _email, password: _password)
        let result = _spine.syncSave(session)

        _handleResult(result)
    }

    // MARK: Private functions

    private func _enterEmail() {
        _email = Input.awaitInputWithValidation(message: "Email:", validation: { (username) -> Bool in
            return !username.isEmpty
        })
    }

    private func _enterPassword() {
        _password = Input.awaitInputWithValidation(message: "Password:", secure: true, validation: { (password) -> Bool in
            return !password.isEmpty
        })
    }

    private func _handleResult(_ result: Result<Session, SpineError>) {
        switch result {
        case .success(let session):
            if let token = session.token {
                _keychain.token = token
                Output.write("Login successful", to: .success)
            } else {
                exit(with: .failure, message: "Login failed")
            }
        case .failure(let error):
            ErrorHandler.processError(error)
        }
    }

}
