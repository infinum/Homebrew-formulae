//
//  PullCommand.swift
//  polyglot
//
//  Created by Filip Beć on 09/11/16.
//
//

import Foundation
import SwiftCLI
import Spine

class PullCommand: Command {

    let name: String = "pull"
    let shortDescription: String = "Pull all translations for a project from the server"
    let signature: String = ""

    private let _spine = SyncSpine.shared
    private let _configManager = ConfigManager.shared
    private let _keychain = Keychain.shared

    func execute(arguments: CommandArguments) throws {
        if _keychain.token == nil {
            let login = LoginCommand()
            login.executeLogin()
        }

        let config = _loadConfiguration()
        _pullTranslations(for: config.projects, language: config.language)
    }

    // MARK: Private

    private func _loadConfiguration() -> Config {
        return _configManager.loadConfig()
    }

    private func _pullTranslations(for projects: [ConfigProject], language: ProgrammingLanguage) {
        projects.forEach { (project) in
            _pullTranslations(for: project, language: language)
        }
    }

    private func _pullTranslations(for project: ConfigProject, language: ProgrammingLanguage) {
        let languages = _pullLanguages(for: project.id)
        let translationKeys = _pullTranslations(for: project.id)

        for language in languages {
            // check language ID
            guard let  languageId = language.id else {
                continue
            }

            // check language code
            guard let languageCode = language.languageCode(oldNaming: project.useOldNaming) else {
                Output.write("Invalid language code for language \(language.name)", to: .error)
                continue
            }

            let translationsContent = TranslationsSerializer.serialized(translationKeys, for: languageId)
            Output.write(
                translationsContent,
                toFileName: languageCode,
                fileExtension: "strings",
                path: project.path
            )
        }

        _generateSourceFiles(at: project.sourceFilesPath, languages: languages, translationKeys: translationKeys, forProgrammingLanguage: language)
        
        Output.write("Translations successfully generated", to: .success)
    }

    private func _pullLanguages(for projectId: String) -> [Language] {
        var query = Query(resourceType: Language.self)
        query.whereAttribute("projectId", equalTo: projectId)

        return _syncLoadAll(with: query, type: Language.self)
    }

    private func _pullTranslations(for projectId: String) -> [TranslationKey] {
        var query = Query(resourceType: TranslationKey.self)
        query.whereAttribute("projectId", equalTo: projectId)
        query.include("translations")
        query.addAscendingOrder("name")

        return _syncLoadAll(with: query, type: TranslationKey.self)
    }

    private func _syncLoadAll<T>(with query: Query<T>, type: T.Type) -> [T] {
        let result = _spine.syncLoadAll(query)

        switch result {
        case .success(let resources):
            return resources.flatMap { $0 as? T }
        case .failure(let error):
            ErrorHandler.processError(error)
        }
        return []
    }

    private func _generateSourceFiles(at path: String?, languages: [Language], translationKeys: [TranslationKey], forProgrammingLanguage programmingLanguage: ProgrammingLanguage) {
        guard let _path = path else {
            Output.write("Skipping generating source files", to: .standard)
            return
        }
        
        let languagesSerializer: LanguagesSerializer.Type
        
        switch programmingLanguage {
        case .swift:
            languagesSerializer = SwiftLanguagesSerializer.self
            
            let stringsContent = StringsEnumSerializer.serialized(translationKeys)
            Output.write(
                stringsContent,
                toFileName: "Strings",
                fileExtension: "swift",
                path: _path
            )
        case .objc:
            languagesSerializer = ObjCLanguagesSerializer.self
        }

        let outputs = languagesSerializer.serialized(languages)
        for key in outputs.keys {
            Output.write(
                outputs[key]!,
                toFileName: "Language",
                fileExtension: key,
                path: _path
            )
        }
        
    }

}
