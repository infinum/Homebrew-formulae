//
//  TranslationKey.swift
//  polyglot
//
//  Created by Filip Beć on 15/11/16.
//
//

import Foundation
import Spine

class TranslationKey: Resource {

    var name: String?

    var createdAt: Date?
    var updatedAt: Date?
    var project: Project?
    var translations: LinkedResourceCollection?

    var projectId: String?
    var languageId: String?

    override class var resourceType: ResourceType {
        return "translation_keys"
    }

    override class var fields: [Field] {
        return fieldsFromDictionary(
            [
                "name": Attribute(),
                "createdAt": DateAttribute().serializeAs("created_at"),
                "updatedAt": DateAttribute().serializeAs("updated_at"),
                "projectId": Attribute().serializeAs("project_id"),
                "languageId": Attribute().serializeAs("language_id"),
                "project": ToOneRelationship(Project.self),
                "translations": ToManyRelationship(Translation.self),
            ]
        )
    }

    func translation(for languageId: String) -> Translation? {
        guard let _translations = translations?.resources as? [Translation] else {
            return nil
        }

        for translation in _translations {
            if translation.language?.id == languageId {
                return translation
            }
        }
        return nil
    }

}
