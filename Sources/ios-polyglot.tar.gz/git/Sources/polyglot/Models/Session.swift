//
//  Session.swift
//  polyglot
//
//  Created by Filip Beć on 10/11/16.
//
//

import Foundation
import Spine

class Session: Resource {
    var email: String?
    var password: String?
    var token: String?

    override class var resourceType: ResourceType {
        return "sessions"
    }

    override class var fields: [Field] {
        return fieldsFromDictionary(
            [
                "email": Attribute(),
                "password": Attribute(),
                "token": Attribute()
            ]
        )
    }

    convenience init(email: String?, password: String?) {
        self.init()
        self.email = email
        self.password = password
    }

}
