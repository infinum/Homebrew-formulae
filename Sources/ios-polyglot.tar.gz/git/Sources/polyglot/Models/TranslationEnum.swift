//
//  TranslationEnum.swift
//  polyglot
//
//  Created by Filip Beć on 18/01/2017.
//
//

import Foundation

class TranslationEnum {

    fileprivate var name: String
    fileprivate var translations: [TranslationCase] = []
    fileprivate var nestedTranslationEnums: [TranslationEnum] = []

    init(name: String) {
        self.name = name
    }
}

extension TranslationEnum {

    func insert(_ components: [String], key: String) {
        var _components = components

        if _components.count > 1 {
            let enumName = _components.removeFirst()

            if let existingEnum = _nestedEnumWithName(enumName) {
                existingEnum.insert(_components, key: key)
            } else {
                let newEnum = TranslationEnum(name: enumName)
                newEnum.insert(_components, key: key)
                nestedTranslationEnums.append(newEnum)
            }
        } else if let caseName = _components.first {
            let translationCase = TranslationCase(
                caseName: caseName,
                translationKey: key
            )
            translations.append(translationCase)
        }
    }

    func serialized(identLevel: Int = 0) -> String {
        var result = String(identLevel: identLevel)

        if translations.isEmpty {
            // enum without any case statement cannot be RawRepresentable
            result += String(format: "public enum %@ {\n", name.cleanEnumName)
        } else {
            result += String(format: "public enum %@: String, StringsProtocol {\n", name.cleanEnumName)
        }

        // Serialize case statements
        translations
            .sorted(by: { $0.caseName < $1.caseName })
            .forEach({ (translationCase) in
                result += String(identLevel: identLevel + 1)
                result += translationCase.serialized()
            })

        if !translations.isEmpty && !nestedTranslationEnums.isEmpty {
            result += "\n"
        }

        // Serialize nested enums
        let serializedNestedEnums = nestedTranslationEnums
            .sorted(by: { $0.name < $1.name })
            .map({
                $0.serialized(identLevel: identLevel + 1)
            })
        result += serializedNestedEnums.joined(separator: "\n")

        result += String(identLevel: identLevel)
        result += "}\n"

        return result
    }

    private func _containsNestedEnumWithName(_ name: String) -> Bool {
        return nestedTranslationEnums.contains(where: { (element) -> Bool in
            return element.name == name
        })
    }

    private func _nestedEnumWithName(_ name: String) -> TranslationEnum? {
        return nestedTranslationEnums.filter({ (element) -> Bool in
            return element.name == name
        }).first
    }
    
}

class TranslationCase {

    let caseName: String
    let translationKey: String

    init(caseName: String, translationKey: String) {
        self.caseName = caseName
        self.translationKey = translationKey
    }

    func serialized() -> String {
        return String(format: "case %@ = \"%@\"\n", caseName.cleanCaseName, translationKey)
    }

}
