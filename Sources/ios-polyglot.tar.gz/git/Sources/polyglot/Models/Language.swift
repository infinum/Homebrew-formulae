//
//  Language.swift
//  polyglot
//
//  Created by Filip Beć on 10/11/16.
//
//

import Foundation
import Spine

class Language: Resource {
    var name: String = ""
    var localName: String = ""
    var locale: String = ""
    var createdAt: Date?
    var updatedAt: Date?
    var projectId: String?

    func languageCode(oldNaming: Bool = false) -> String? {
        if oldNaming {
            return locale.components(separatedBy: "_").first
        }
        return locale.lowercased()
    }

    override class var resourceType: ResourceType {
        return "languages"
    }

    override class var fields: [Field] {
        return fieldsFromDictionary(
            [
                "name": Attribute(),
                "localName": Attribute().serializeAs("local_name"),
                "locale": Attribute(),
                "createdAt": DateAttribute().serializeAs("created_at"),
                "updatedAt": DateAttribute().serializeAs("updated_at"),
                "projectId": Attribute().serializeAs("project_id"),
            ]
        )
    }
}
