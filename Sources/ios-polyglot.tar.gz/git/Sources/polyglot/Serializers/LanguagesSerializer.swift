//
//  LanguagesSerializer.swift
//  polyglot
//
//  Created by Filip Beć on 29/11/16.
//
//

import Foundation

typealias FileExtension = String
typealias FileContents = String

protocol LanguagesSerializer {
    static func serialized(_ languages: [Language]) -> [FileExtension: FileContents]
    static func sortedLanguages(languages: [Language]) -> [Language]
}

extension LanguagesSerializer {
    static func sortedLanguages(languages: [Language]) -> [Language] {
        return languages.sorted(by: { $0.name < $1.name })
    }
}

class SwiftLanguagesSerializer: LanguagesSerializer {
    static func serialized(_ languages: [Language]) -> [FileExtension: FileContents] {
        let allLanguagesString = SwiftLanguagesSerializer.languagesString(languages: languages)
        let allLanguagesArray = SwiftLanguagesSerializer.languagesArray(languages: languages)
        
        return ["swift": String(format: serializerFormat(), allLanguagesString, allLanguagesArray)]
    }
    
    static private func languagesString(languages: [Language]) -> String {
        return sortedLanguages(languages: languages)
            .map({ String(identLevel: 1) + SwiftLanguagesSerializer.serializedStaticProperty(language: $0) })
            .joined(separator: "\n")
    }
    
    static private func languagesArray(languages: [Language]) -> String {
        return sortedLanguages(languages: languages)
            .map({ String(identLevel: 2) + SwiftLanguagesSerializer.serializedLanguageValue(language: $0) })
            .joined(separator: ",\n")
    }
    
    static private func serializerFormat() -> String {
        let ident = String(identLevel: 1)
        let lines: [String] = [
            "import Foundation\n",
            "public struct Language {\n",
            ident + "public let name: String",
            ident + "public let localName: String",
            ident + "public let locale: String",
            ident + "public let languageCode: String\n",
            "%@\n",
            ident + "public static let all = [",
            "%@",
            ident + "]\n",
            "}\n"
        ]
        return lines.joined(separator: "\n")
    }
    
    static private func serializedStaticProperty(language: Language) -> String {
        let parameters: String = [
            "name: \"\(language.name)\"",
            "localName: \"\(language.localName)\"",
            "locale: \"\(language.locale)\"",
            "languageCode: \"\(language.languageCode() ?? "")\"",
            ].joined(separator: ", ")
        
        return String(format: "public static let %@ = Language(%@)", language.name.cleanVaribleName, parameters)
    }
    
    static private func serializedLanguageValue(language: Language) -> String {
        return String(format: "Language.%@", language.name.cleanVaribleName)
    }
}

class ObjCLanguagesSerializer: LanguagesSerializer {
    static func serialized(_ languages: [Language]) -> [FileExtension: FileContents] {
        return ["h": header(languages: languages), "m": implementation(languages: languages)]
    }
    
    
    static private func implementation(languages: [Language]) -> String {
        let ident = String(identLevel: 1)
        let dident = String(identLevel: 2)
        let lines: [String] = [
            "#import \"Language.h\"\n",
            "@interface Language()",
            "@property (nonatomic, strong) NSString *name;",
            "@property (nonatomic, strong) NSString *localName;",
            "@property (nonatomic, strong) NSString *locale;",
            "@property (nonatomic, strong) NSString *languageCode;\n",
            "@end\n",
            "@implementation Language\n",
            "- (instancetype)initWithName:(NSString *)name localName:(NSString *)localName locale:(NSString *)locale languageCode:(NSString *)languageCode {",
            ident + "if (self = [super init]) {",
            dident + "self.name = name;",
            dident + "self.localName = localName;",
            dident + "self.locale = locale;",
            dident + "self.languageCode = languageCode;",
            ident + "}",
            ident + "return self;",
            "}\n",
            sortedLanguages(languages: languages)
                .map(serializedStaticImplementation)
                .joined(separator:"\n"),
            "+ (NSArray<Language *>*)allLanguages {",
            ident + "return @[",
            sortedLanguages(languages: languages)
                .map { dident + "[Language \($0.name.cleanVaribleName)]" }
                .joined(separator: ",\n"),
            ident + "];",
            "}",
            "@end"
        ]
        return lines.joined(separator: "\n")
    }
    
    static private func header(languages: [Language]) -> String {
        let lines: [String] = [
            "#import <Foundation/Foundation.h>\n",
            "@interface Language : NSObject\n",
            "@property (nonatomic, readonly) NSString *name;",
            "@property (nonatomic, readonly) NSString *localName;",
            "@property (nonatomic, readonly) NSString *locale;",
            "@property (nonatomic, readonly) NSString *languageCode;\n",
            "+ (NSArray<Language *>*)allLanguages;\n",
            sortedLanguages(languages: languages)
                .map(serializedStaticDeclaration)
                .joined(separator: "\n"),
            "\n",
            "@end\n"
        ]
        return lines.joined(separator: "\n")
    }
    
    private static func serializedStaticDeclaration(language: Language) -> String {
        return "+ (instancetype)\(language.name.cleanVaribleName);"
    }

    private static func serializedStaticImplementation(language: Language) -> String {
        let ident = String(identLevel: 1)
        let lines: [String] = [
            "+ (instancetype)\(language.name.cleanVaribleName) {",
            ident + "return [[Language alloc] initWithName:@\"\(language.name)\" localName:@\"\(language.localName)\" locale:@\"\(language.locale)\" languageCode:@\"\(language.languageCode() ?? "")\"];",
            "}"
        ]
        
        return lines.joined(separator: "\n")
    }
    
}

