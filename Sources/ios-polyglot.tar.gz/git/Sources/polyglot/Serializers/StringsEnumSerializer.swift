//
//  StringsEnumSerializer.swift
//  polyglot
//
//  Created by Filip Beć on 29/11/16.
//
//

import Foundation

class StringsEnumSerializer {

    static func serialized(_ translationKeys: [TranslationKey]) -> String {
        let root = TranslationEnum(name: "Strings")

        for key in translationKeys {
            guard let translationKey = key.name else {
                continue
            }
            let components = translationKey.components(separatedBy: ".")
            root.insert(components, key: translationKey)
        }

        var output = root.serialized()
        output += _generateInfrastructure()
        return output
    }

    private static func _generateInfrastructure() -> String {
        let ident = String(identLevel: 1)
        return [
            "\npublic protocol StringsProtocol: RawRepresentable {\n",
            ident + "var localized: String { get }\n",
            ident + "func localized(with args: CVarArg...) -> String\n",
            "}\n\n",

            "public extension StringsProtocol where RawValue == String {\n",

            ident + "var localized: String {\n",
            ident + ident + "return self.rawValue.localized\n",
            ident + "}\n\n",

            ident + "func localized(with args: CVarArg...) -> String {\n",
            ident + ident + "return String(format: self.rawValue.localized, arguments: args)\n",
            ident + "}\n",

            "}\n",
        ].joined()
    }
    
}
