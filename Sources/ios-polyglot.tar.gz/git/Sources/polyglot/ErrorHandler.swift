//
//  ErrorHandler.swift
//  polyglot
//
//  Created by Filip Beć on 11/11/16.
//
//

import Foundation
import Spine

class ErrorHandler {

    static func processError(_ error: SpineError) {
        switch error {
        case .networkError(let error):
            exit(with: .failure, message: error.localizedDescription)
        case .serverError(let statusCode, let apiErrors):
            // logout user if token has expired
            switch statusCode {
            case 401:
                Keychain.shared.token = nil
            case 404:
                Output.write("Resource not found", to: .error)
            default:
                break
            }

            apiErrors?.forEach({ (error) in
                Output.write(error.detail, to: .error)
            })
            exit(with: .failure)
        case .unknownError:
            exit(with: .failure, message: "An unknown error occured.")
        default:
            break;
        }
    }

}
