//
//  Output.swift
//  polyglot
//
//  Created by Filip Beć on 11/11/16.
//
//

import Foundation

enum OutputType {
    case standard
    case error
    case success
}

class Output {

    static func write(_ message: String?, to output: OutputType = .standard) {
        guard let _message = message else {
            return
        }

        switch output {
        case .standard:
            fputs("\u{001B}[;m\(_message)\n", stdout)
        case .error:
            fputs("\u{001B}[0;31m[ERROR]: \(_message)\n", stderr)
        case .success:
            fputs("\u{001B}[0;32m\(_message)\n", stdout)
        }
    }

    static func write(_ message: String, toFileName fileName: String, fileExtension: String, path: String) {

        var fileURL = URL(fileURLWithPath: path, isDirectory: true)
        fileURL.appendPathComponent(fileName)
        fileURL.appendPathExtension(fileExtension)

        let fileManager = FileManager.default
        var isDir : ObjCBool = false

        if fileManager.fileExists(atPath: path, isDirectory:&isDir) {
            if !isDir.boolValue {
                // file exists and is not a directory
                exit(with: .failure, message: "File at path \(path) already exist!")
            }
        } else {
            // file doesn't exist
            _createDirectory(at: path)
        }

        let success = FileManager.default.createFile(
            atPath: fileURL.path,
            contents: message.data(using: .utf8),
            attributes: nil
        )

        if !success {
            exit(with: .failure, message: "Cannot create file at path \(fileURL.path)")
        }
    }

    private static func _createDirectory(at path: String) {
        do {
            try FileManager.default.createDirectory(
                atPath: path,
                withIntermediateDirectories: true,
                attributes: nil
            )
        } catch let error {
            exit(with: .failure, message: error.localizedDescription)
        }
    }

}
