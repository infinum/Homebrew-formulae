//
//  Keychain.swift
//  polyglot
//
//  Created by Filip Beć on 09/11/16.
//
//

import Foundation
import Security

class Keychain {

    static var shared: Keychain = Keychain()
    private init() {}

    private var _token: String? {
        willSet {
            if let token = newValue {
                SyncSpine.shared.login(with: token)
            } else {
                SyncSpine.shared.logout()
            }
        }
    }

    var token: String? {
        get {
            guard let token = _token else {
                let savedToken = value(forKey: tokenKey)
                _token = savedToken
                return savedToken
            }
            return token
        }
        set {
            _token = newValue
            set(newValue, forKey: tokenKey)
        }
    }

    private let tokenKey = "token"
}

// MARK: - *** Private methods ***

fileprivate extension Keychain {

    @discardableResult
    func set(_ value: String?, forKey key: String) -> Bool {
        guard let newValue = value else {
            return deleteValue(forKey: key)
        }

        if valueExists(forKey: key) {
            return update(newValue, forKey: key)
        } else {
            return create(newValue, forKey: key)
        }
    }

    func value(forKey key: String) -> String? {
        guard let valueData = valueData(forKey: key) else {
            return nil
        }
        return NSString(data: valueData, encoding: String.Encoding.utf8.rawValue) as String?
    }

    private func deleteValue(forKey key: String) -> Bool {
        let searchDictionary = newSearchDictionary(forKey: key)
        let status = SecItemDelete(searchDictionary as CFDictionary)

        return status == errSecSuccess
    }

    private func valueExists(forKey key: String) -> Bool {
        return valueData(forKey: key) != nil
    }

    private func create(_ value: String, forKey key: String) -> Bool {
        var dictionary = newSearchDictionary(forKey: key)

        dictionary[kSecValueData as String] = value.data(using: String.Encoding.utf8, allowLossyConversion: false) as AnyObject?

        let status = SecItemAdd(dictionary as CFDictionary, nil)
        return status == errSecSuccess
    }

    private func update(_ value: String, forKey key: String) -> Bool {
        let searchDictionary = newSearchDictionary(forKey: key)
        var updateDictionary = [String: AnyObject]()

        updateDictionary[kSecValueData as String] = value.data(using: String.Encoding.utf8, allowLossyConversion: false) as AnyObject?

        let status = SecItemUpdate(searchDictionary as CFDictionary, updateDictionary as CFDictionary)

        return status == errSecSuccess
    }

    private func valueData(forKey key: String) -> Data?  {
        var searchDictionary = newSearchDictionary(forKey: key)

        searchDictionary[kSecMatchLimit as String] = kSecMatchLimitOne
        searchDictionary[kSecReturnData as String] = kCFBooleanTrue

        var retrievedData: AnyObject?
        let status = SecItemCopyMatching(searchDictionary as CFDictionary, &retrievedData)

        var data: Data?
        if status == errSecSuccess {
            data = retrievedData as? Data
        }

        return data
    }

    private func newSearchDictionary(forKey key: String) -> [String: AnyObject] {
        let encodedIdentifier = key.data(using: String.Encoding.utf8, allowLossyConversion: false)

        var searchDictionary = basicDictionary()
        searchDictionary[kSecAttrGeneric as String] = encodedIdentifier as AnyObject?
        searchDictionary[kSecAttrAccount as String] = encodedIdentifier as AnyObject?

        return searchDictionary
    }

    private func basicDictionary() -> [String: AnyObject] {
        let serviceName = "polyglot"
        return [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: serviceName as AnyObject,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlocked
        ]
    }

}
