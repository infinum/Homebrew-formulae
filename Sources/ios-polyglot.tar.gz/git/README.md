# iOS Polyglot CLI [![Build Status](https://app.bitrise.io/app/e9c3fdaf0c991fc1/status.svg?token=sBMkQ6kMVjdVEDbM72z4lg&branch=master)](https://app.bitrise.io/app/e9c3fdaf0c991fc1)
## Installation

If you use old polyglot-cli please uninstall it first:

```
#!bash

$ sudo gem uninstall polyglot-cli
```

### Install with Homebrew

Add brew tap by running (this needs to be done only before the first installation):

```
$ brew tap infinum/formulae
$ brew tap-pin infinum/formulae # This will set infinum/forulae as the preffered tap 
                                # when resolving conflicts about formulae with same names.
                                # If you skip this step, to install polyglot (by Infinum), 
                                # use infinum/formulae/polyglot
```

Then to install polyglot simply run:
```
$ brew update
$ brew install polyglot
```

### Install from source

Clone this repo, move to the root folder, build and install new Polyglot CLI.

```
#!bash

$ git clone git@github.com:infinum/iOS-Polyglot.git
$ cd ios-polyglot-cli
$ make && make install
```

You can check if everything is OK by :

```
#!bash

$ polyglot version
```
You should see output: _Version: 1.0_

## Usage
### Login
You will have to login with your Infinum ID if you want to use polyglot:

```
#!bash

$ polyglot login --email <email>
```

If your login action is successful, polyglot will ask you to access Keychain.  There it will save your access token, so you don’t have to enter your credentials every time when you use `polyglot` command.

### Projects
If you want to see all polyglot projects and their `IDs` enter: 

```
#!bash

$ polyglot projects
```

If you want to find specific project by name you can pipe output of the `polyglot projects` command to `grep` command. For example: 

```
#!bash

$ polyglot projects | grep -i 'currency'
```

### Setup
To setup polyglot in your Xcode project use: 

```
#!bash

$ polyglot setup
```
It will ask you for some information, but for most of the cases you can just press enter and it will use default value. Also, it will create `polyglot.yml` file which you can edit later and add additional Polyglot projects.

Also you can pass optional parameter `—list` or `-l` . It will give you a list of all available Polyglot projects - the same as `polyglot projects` command.

### Legacy projects

New style translations will create files names `en_US.strings` for example, and some old projects still use old naming in the style of `en.strings`. To get around this issue, you either need to migrate your project to use the new naming (be mindful of existing app's settings), or add this line under your path value:


```
#!yaml

useOldNaming: true
```


### Pull 
Finally, to fetch translations use: 

```
#!bash

$ polyglot pull
```

### Development
When doing development on this project, any changes that are made on the master branch will automatically trigger a build that will handle the deployment of the tarball and brew formula to Infinum's Homebrew tap. The script used for deployment can be found at  ``.deploy/deployment.sh``.  Since the build is triggered every time there is a commit pushed to master branch, all active development should be done in other branches.
