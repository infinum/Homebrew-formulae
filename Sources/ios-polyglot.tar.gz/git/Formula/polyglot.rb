class Polyglot < Formula
    desc "Infinum's polyglot tool for iOS"
    homepage "https://github.com/infinum/iOS-Polyglot"
    head "git@github.com:infinum/iOS-Polyglot.git", :using => :git
    #url "https://github.com/infinum/Homebrew-formulae/raw/master/Sources/ios-polyglot.tar.gz"
    sha256 "20426efff6a9b32fe609d423cdf86182c004a391511e324ceae06c0674cd1ed6"
  
    def install
      system "swift", "build", "-c", "release", "-v", "--build-path=#{bin}", "--disable-sandbox"
      system "ln", "-s", "#{bin}/polyglot", "#{bin}/release/polyglot"
      @bin = "#{bin}/release"
    end
  
    test do
      system "false"
    end
  end
