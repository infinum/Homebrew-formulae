//
//  Translation.swift
//  polyglot
//
//  Created by Filip Beć on 15/11/16.
//
//

import Foundation
import Spine

class Translation: Resource {
    var value: String?
    var createdAt: Date?
    var updatedAt: Date?
    var language: Language?

    override class var resourceType: ResourceType {
        return "translations"
    }

    override class var fields: [Field] {
        return fieldsFromDictionary(
            [
                "value": Attribute(),
                "createdAt": DateAttribute().serializeAs("created_at"),
                "updatedAt": DateAttribute().serializeAs("updated_at"),
                "language": ToOneRelationship(Language.self)
            ]
        )
    }

}
