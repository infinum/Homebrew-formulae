class Polyglot < Formula
    desc "Infinum's polyglot tool for iOS"
    homepage "https://github.com/infinum/iOS-Polyglot"
    head "git@github.com:infinum/iOS-Polyglot.git", :using => :git
    sha256 "a2577a2e4d3f2cf19c9f1344aec155094139c1044f6106214815d7f4981fca08"
  
    def install
      system "swift", "build", "-c", "release", "-v", "--build-path=#{bin}", "--disable-sandbox"
      @bin = "#{bin}/release"
    end
  
    test do
      system "false"
    end
  end